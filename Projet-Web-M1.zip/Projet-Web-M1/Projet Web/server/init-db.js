const articles = require('./data/articles.js')
const { Client } = require('pg')
const bcrypt = require('bcrypt')

const client = new Client({
  user: 'postgres',
  host: 'localhost',
  password: 'admin',
  database: 'postgres'
 })

client.connect()

async function run () {
  await client.query({
    text: `CREATE TABLE users
    (
        id serial PRIMARY KEY,
        email text,
        password text
    )`,
  })
  await client.query({
    text: `CREATE TABLE articles
    (
        id serial PRIMARY KEY,
        name text,
        description text,
        image text,
        price text
    )`,
  })
  for (const article of articles) {
    await client.query({
      text: `INSERT INTO articles(name, description, image, price)
      VALUES ($1, $2, $3, $4)`,
      values: [article.name, article.description, article.image, article.price]
    })
  }
  const hash = await bcrypt.hash('admin', 10)
  await client.query({
    text: `INSERT INTO users
    VALUES ($1, $2, $3)`,
    values: [1, 'admin', hash]
  })
  console.log('importation terminée')
  client.end()
}

run()