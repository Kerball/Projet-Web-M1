const express = require('express')
const router = express.Router()
const bcrypt = require('bcrypt')
const { Client } = require('pg')

const client = new Client({
 user: 'postgres',
 host: 'localhost',
 password: 'admin',
 database: 'postgres'
})

client.connect()

const users = []

class Panier {
  constructor () {
    this.createdAt = new Date()
    this.updatedAt = new Date()
    this.articles = []
  }
}

router.put('/api/parapluie/:parapluieId', (req, res) => {
  const parapluieId = parseInt(req.params.parapluieId)
  const taille = req.body.taille
  const prix = req.body.prix
  const para = parapluies.find(p => p.id === parapuieId)
  if (!para) {
    res.status(404).send()
    return
  }
  res.json(para)
})


router.use((req, res, next) => {
  if (typeof req.session.panier === 'undefined') {
    req.session.panier = new Panier()
  }
  next()
})

router.post('/login', async (req, res) => {
  const email = req.body.email
  const password = req.body.password

  const result = await client.query({
    text: 'SELECT * FROM users WHERE email=$1',
    values: [email]
  })

  if (result.rows.length === 0) {
    res.status(401).json({
      message: 'user doesnt exist'
    })
    return
  }
  const user = result.rows[0]

  if (await bcrypt.compare(password, user.password)) {
    req.session.userId = user.id
    res.json({
      id: user.id,
      email: user.email
    })
  } else {
    res.status(401).json({
      message: 'bad password'
    })
    return
  }
})

router.post('/register', async (req, res) => {
  const email = req.body.email
  const password = req.body.password

  const result = await client.query({
    text: 'SELECT * FROM users WHERE email=$1',
    values: [email]
  })

  if (result.rows.length > 0) {
    res.status(401).json({
      message: 'user already exists'
    })
    return
  }
  const hash = await bcrypt.hash(password, 10)

  await client.query({
    text: `INSERT INTO users(email, password)
    VALUES ($1, $2)
    `,
    values: [email, hash]
  })
  res.send('ok')
})

router.get('/me', async (req, res) => {
  if (typeof req.session.userId === 'undefined') {
    res.status(401).json({ message: 'not connected' })
    return
  }

  const result = await client.query({
    text: 'SELECT id, email FROM users WHERE id=$1',
    values: [req.session.userId]
  })

  res.json(result.rows[0])
})


router.get('/panier', (req, res) => {
  res.json(req.session.panier)
})

router.post('/panier', async function(req, res) {
  const articleId = req.body.articleId
  const quantity = req.body.quantity
  
  if (articleId === '' || quantity === '' || parseInt(quantity) <= 0) {
    res.status(400).json({ message: 'bad request' })
    return
  }

  let articles = await getArticles()
  if (articles.filter(article => article.id == articleId).length == 0) {
    res.status(501).json({ message: 'Article does not exist' })
    return
  }

  if (req.session.panier.articles.filter(article => article.id == articleId).length == 1) {
    res.status(400).json({ message: 'Article already in basket' })
    return
  } else {
    const newArticle = {
      "id": articleId,
      "quantity": parseInt(quantity)
    }
    req.session.panier.articles.push(newArticle);
  }

  res.json(req.session.panier.articles)
})

router.post('/panier/pay', (req, res) => {
  if (typeof req.session.userId === 'number') {
    req.session.panier.articles = []
    res.send('ok')
  } else {
    res.status(401).json({ message: "vous n'êtes pas connecté" })
  }
})

router.put('/panier/:articleId', async function(req, res) {
  const articleId = req.params.articleId
  const quantity = req.body.quantity
  
  if (articleId === '' || quantity === '' || parseInt(quantity) <= 0) {
    res.status(400).json({ message: 'bad request' })
    return
  }

  let articles = await getArticles()
  if (articles.filter(article => article.id == articleId).length == 0) {
    res.status(501).json({ message: 'Article does not exist' })
    return
  }

  if (req.session.panier.articles.filter(article => article.id == articleId).length == 0) {
    res.status(400).json({ message: 'Article not in basket' })
    return
  } else {

    req.session.panier.articles.filter(article => article.id == articleId)[0].quantity = quantity
  }

  res.json(req.session.panier.articles)
})


router.delete('/panier/:articleId', (req, res) => {
  const articleId = req.params.articleId
  
  if (articleId === '') {
    res.status(400).json({ message: 'bad request' })
    return
  }
  
  req.session.panier.articles = req.session.panier.articles.filter(article => article.id != articleId)

  res.json(req.session.panier.articles)
})


router.get('/articles', async (req, res) => {
  const result = await client.query({
    text: 'SELECT * FROM articles'
  })
  res.json(result.rows)
})


router.post('/article', async (req, res) => {
  const name = req.body.name
  const description = req.body.description
  const image = req.body.image
  const price = parseInt(req.body.price)

  if (typeof name !== 'string' || name === '' ||
      typeof description !== 'string' || description === '' ||
      typeof image !== 'string' || image === '' ||
      isNaN(price) || price <= 0) {
    res.status(400).json({ message: 'bad request' })
    return
  }

  const result = await client.query({
    text: `INSERT INTO articles(name, description, image, price)
    VALUES ($1, $2, $3, $4)
    RETURNING *
    `,
    values: [name, description, image, price]
  })
  const id = result.rows[0].id

  res.json({
    id: id,
    name: name,
    description: description,
    image: image,
    price: price
  })
})


async function parseArticle (req, res, next) {
  const articleId = parseInt(req.params.articleId)

  if (isNaN(articleId)) {
    res.status(400).json({ message: 'articleId should be a number' })
    return
  }
  req.articleId = articleId

  const result = await client.query({
    text: 'SELECT * FROM articles WHERE id=$1',
    values: [articleId]
  })
  if (!result.rows.length) {
    res.status(404).json({ message: 'article ' + articleId + ' does not exist' })
    return
  }
  req.article = result.rows[0]
  next()
}

router.route('/article/:articleId')

  .get(parseArticle, (req, res) => {
    res.json(req.article)
  })

  .put(parseArticle, async (req, res) => {
    console.log("ICI ???")
    console.log(req.body)
    const name = req.body.name
    const description = req.body.description
    console.log(description)
    const image = req.body.image
    const price = parseInt(req.body.price)

    await client.query({
      text: `UPDATE articles
              SET name=$1,
              description=$2,
              image=$3,
              price=$4
            WHERE id=$5
            `,
      values: [name, description, image, price, req.articleId]
    })
    res.send()
  })

  .delete(parseArticle, async (req, res) => {
    await client.query({
      text: 'DELETE FROM articles WHERE id=$1',
      values: [req.articleId]
    })
    res.send()
  })

router.get('/users', async function (req, res) {
  let response = await client.query({text: `SELECT id, email FROM users`})
  res.json(response.rows)
})

async function getArticles() {
  response = await client.query({
    text: `SELECT * FROM articles`,
  })
  let articles = response.rows
  return articles
}

module.exports = router
