const Home = window.httpVueLoader('./components/Home.vue')
const Panier = window.httpVueLoader('./components/Panier.vue')
const Register = window.httpVueLoader('./components/Register.vue')
const Login = window.httpVueLoader('./components/Login.vue')
const Management = window.httpVueLoader('./components/Management.vue')
const Users = window.httpVueLoader('./components/Users.vue')

const routes = [
  { path: '/', component: Home },
  { path: '/panier', component: Panier },
  { path: '/register', component: Register },
  { path: '/login', component: Login },
  { path: '/management', component: Management },
  { path: '/users', component: Users }
]

const router = new VueRouter({
  routes
})

var app = new Vue({
  router,
  el: '#app',
  data: {
    articles: [],
    panier: {
      createdAt: null,
      updatedAt: null,
      articles: []
    },
    user: {},
    users: [],
    isConnected: false
  },
  async mounted () {
    const res = await axios.get('/api/articles')
    this.articles = res.data
    const res2 = await axios.get('/api/panier')
    this.panier = res2.data
    try {
      const res3 = await axios.get('/api/me')
      this.user = res3.data
      this.isConnected = true
    } catch (err) {
      if (err.response?.status === 401) {
        this.isConnected = false
      } else {
        console.log('error', err)
      }
    }
  },
  methods: {
    async putArticleQuantity(articleId, quantity) {
      const res = await axios.put('/api/panier/' + articleId, {"quantity": quantity})
      this.panier.articles = res.data
    },
    async addArticle (article) {
      const res = await axios.post('/api/article', article)
      this.articles.push(res.data)
    },
    async addToPanier (articleId) {
      const article = {
        "articleId": articleId,
        "quantity": 1
      }
      const res = await axios.post('/api/panier', article)
      this.panier.articles = res.data
    },
    async removeFromPanier (articleId) {
      const res = await axios.delete('/api/panier/' + articleId)
      this.panier.articles = res.data
    },
    async updateArticle (newArticle) {
      await axios.put('/api/article/' + newArticle.id, newArticle)
      const article = this.articles.find(a => a.id === newArticle.id)
      article.name = newArticle.name
      article.description = newArticle.description
      article.image = newArticle.image
      article.price = newArticle.price
    },
    async deleteArticle (articleId) {
      await axios.delete('/api/article/' + articleId)
      const index = this.articles.findIndex(a => a.id === articleId)
      this.articles.splice(index, 1)
    },
    async pay () {
      await axios.post('/api/panier/pay')
      this.panier.articles = []
    },
    async login (user) {
      const res = await axios.post('/api/login', user)
      this.user = res.data
      this.isConnected = true
      this.$router.push('/')
    },
    async getUsers() {
      let response = await axios.get('/api/users')
      this.users = response.data
      console.log("vue-application.js", this.users)
    },
    async disconnect() {
      console.log("ludo")
      this.isConnected = false
    }
  }
})
