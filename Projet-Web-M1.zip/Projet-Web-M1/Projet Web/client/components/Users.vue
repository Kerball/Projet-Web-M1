<template>
  <div>
    <button v-if="isConnected" @click="$emit('disconnect')" class="btn btn-danger" style="margin-bottom : 50"> Se déconnecter </button> 
    <div v-if="isConnected"> 
        <h2 style="color: rgb(255, 115, 0)">Users</h2>
        <div v-for="user in users" :key="user.id">
            <div style="color: rgb(255, 115, 0);font-size: large;margin-bottom: 20;"> {{ user.id }} : {{ user.email }} </div>
        </div>
    </div>
    <div v-else>
        <div style="color: rgb(255, 115, 0)"> Vous n'êtes pas connecté, veuillez vous connecter pour avoir accès à la page management. </div>
    </div>
  </div>
</template>

<script>
module.exports = {
  props: {
    users: { type: Array },
    isConnected: { type: Boolean }
  },
  async mounted () {
    await this.getUsers()
  },
  methods: {
    async getUsers() {
        this.$emit('get-users')
    }
  }
}
</script>

<style scoped>
</style>
