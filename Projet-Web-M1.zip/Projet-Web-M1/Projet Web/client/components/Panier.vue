<template>
  <div>
    <button v-if="isConnected" @click="$emit('disconnect')" class="btn btn-danger" style="margin-bottom : 50"> Se déconnecter </button> 
    <h2 style="color: rgb(255, 115, 0)">Mon Panier</h2>
      <article v-for="article in articles.filter(article => panier.articles.find(panierArticle => panierArticle.id == article.id))" :key="article.id">
      <div class="article-img">
        <div :style="{ backgroundImage: 'url(' + article.image + ')' }">
        </div>
      </div>
      <div class="article-content" v-if="editingArticle.id !== article.id">
        <div class="article-title">
          <h2>{{ article.name }} - {{ article.price }}€</h2>
          <div>
          <button v-on:click ="incrementArticleQuantity(article.id)" class="btn btn-primary">Le panier contient {{ getArticleQuantity(article.id) }} de cet article</button>
          <button v-if="panier.articles.filter(articlePanier => articlePanier.id == article.id).length === 0" @click="addToPanier(article)" >Ajouter au panier</button>
          <button v-if="panier.articles.filter(articlePanier => articlePanier.id == article.id).length !== 0" @click="removeFromPanier(article)" class="btn btn-primary">Retirer du panier</button>
          </div>
        </div>
        <p>{{ article.description }}</p>
      </div>
      <div class="article-content" v-else>
        <div class="article-title">
          <h2><input type="text" v-model="editingArticle.name"> - <input type="number" v-model="editingArticle.price"></h2>
          <div>
            <button @click="sendEditArticle()">Valider</button>
            <button @click="abortEditArticle()">Annuler</button>
          </div>
        </div>
        <p><textarea v-model="editingArticle.description"></textarea></p>
        <input type="text" v-model="editingArticle.image" placeholder="Lien vers l'image">
      </div>
    </article>
    <button @click="pay" v-if="isConnected" class="btn btn-success">Payer</button>
    <router-link to="/login" v-else>Se connecter pour payer</router-link>
  </div>
</template>

<script>
module.exports = {
  props: {
    articles: { type: Array, default: [] },
    panier: { type: Object },
    isConnected: { type: Boolean }
  },
  data () {
    return {
      newArticle: {
        name: '',
        description: '',
        image: '',
        price: 0
      },
      editingArticle: {
        id: -1,
        name: '',
        description: '',
        image: '',
        price: 0
      },
      data: []
    }
  },
  methods: {
    find (articleId) {
      return this.articles.find(article => article.id === articleId)
    },
    pay () {
      this.$emit('pay')
    },
    getArticleQuantity (articleId) {
      return this.panier.articles.find(panierArticle => panierArticle.id == articleId).quantity
    },
    incrementArticleQuantity(articleId) {
      this.$emit('put-article-quantity', articleId, this.getArticleQuantity(articleId) + 1)
    },
    addArticle () {
      this.$emit('add-article', this.newArticle)
    },
    deleteArticle (articleId) {
      this.$emit('delete-article', articleId)
    },
    addToPanier(article) {
      this.$emit('add-to-panier', article.id)
    },
    removeFromPanier(article) {
      this.$emit('remove-from-panier', article.id)
    },
    editArticle (article) {
      this.editingArticle.id = article.id
      this.editingArticle.name = article.name
      this.editingArticle.description = article.description
      this.editingArticle.image = article.image
      this.editingArticle.price = article.price
    },
    sendEditArticle () {
      this.$emit('update-article', this.editingArticle)
      this.abortEditArticle()
    },
    abortEditArticle () {
      this.editingArticle = {
        id: -1,
        name: '',
        description: '',
        image: '',
        price: 0
        }
      }
  }
}
</script>

<style scoped>
article {
  display: flex;
}

.article-img {
  margin-bottom: 100;
  flex: 1;
}

.article-img div {
  width: 400px;
  height: 200px;
  background-size: cover;
}

.article-content {
  color : rgb(255, 102, 0);
  flex: 3;
}

.article-title {
  display: flex;
  justify-content: space-between;
}

textarea {
  width: 100%;
}
</style>
