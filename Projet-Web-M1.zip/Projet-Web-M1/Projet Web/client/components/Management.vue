<template>
  <div>
    <button v-if="isConnected" @click="$emit('disconnect')" class="btn btn-danger" style="margin-bottom : 50"> Se déconnecter </button> 
    <div v-if="isConnected"> 
        <article v-for="article in articles" :key="article.id">
        <div class="article-img">
            <div :style="{ backgroundImage: 'url(' + article.image + ')' }">
            </div>
        </div>
        <div class="article-content" v-if="editingArticle.id !== article.id">
            <div class="article-title">
            <h2>{{ article.name }} - {{ article.price }}€</h2>
            <div>
            <button class="btn btn-primary" @click="deleteArticle(article.id)">Supprimer</button>
            <button class="btn btn-primary" @click="editArticle(article)">Modifier</button>
            </div>
            </div>
            <p>{{ article.description }}</p>
        </div>
        <div class="article-content" v-else>
            <div class="article-title">
            <h2><input type="text" v-model="editingArticle.name"> - <input type="number" v-model="editingArticle.price"></h2>
            <div>
                <button @click="sendEditArticle()">Valider</button>
                <button @click="abortEditArticle()">Annuler</button>
            </div>
            </div>
            <p><textarea v-model="editingArticle.description"></textarea></p>
            <input type="text" v-model="editingArticle.image" placeholder="Lien vers l'image">
        </div>
        </article>
        <form @submit.prevent="addArticle">
        <h2 style="color: rgb(255, 115, 0)">Nouveau produit à ajouter</h2>
        <input type="text" v-model="newArticle.name" placeholder="Nom du produit" required>
        <input type="number" v-model="newArticle.price" placeholder="Prix" required>
        <textarea type="text" v-model="newArticle.description" required></textarea>
        <input type="text" v-model="newArticle.image" placeholder="Lien vers l'image">
        <button type="submit" class="btn btn-primary">Ajouter</button>
        </form>
    </div>
    <div v-else>
        <div style="color: rgb(255, 115, 0)"> Vous n'êtes pas connecté, veuillez vous connecter pour avoir accès à la page management. </div>
    </div>
  </div>
</template>

<script>
module.exports = {
  props: {
    articles: { type: Array, default: [] },
    isConnected: { type: Boolean }
  },
  data () {
    return {
      newArticle: {
        name: '',
        description: '',
        image: '',
        price: 0
      },
      editingArticle: {
        id: -1,
        name: '',
        description: '',
        image: '',
        price: 0
      }
    }
  },
  methods: {
    addArticle () {
      this.$emit('add-article', this.newArticle)
    },
    deleteArticle (articleId) {
      this.$emit('delete-article', articleId)
    },
    editArticle (article) {
      this.editingArticle.id = article.id
      this.editingArticle.name = article.name
      this.editingArticle.description = article.description
      this.editingArticle.image = article.image
      this.editingArticle.price = article.price
    },
    sendEditArticle () {
      this.$emit('update-article', this.editingArticle)
      this.abortEditArticle()
    },
    abortEditArticle () {
      this.editingArticle = {
        id: -1,
        name: '',
        description: '',
        image: '',
        price: 0
      }
    }
  }
}
</script>

<style scoped>
article {
  display: flex;
}

.article-img {
  margin-bottom: 100;
  flex: 1;
}

.article-img div {
  width: 400px;
  height: 200px;
  background-size: cover;
}

.article-content {
  color : rgb(255, 102, 0);
  flex: 3;
}

.article-title {
  
  display: flex;
  justify-content: space-between;
}

textarea {
  width: 100%;
}
</style>